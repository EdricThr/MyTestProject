package com.DesignPatterns.״̬ģʽ1;

public interface State {
    void handle(String sampleParameter);
}