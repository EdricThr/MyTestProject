package com.DesignPatterns.״̬ģʽ2;

public interface VoteState {

    void voite(String user, String voteItem, VoteManager voteManager);
}
